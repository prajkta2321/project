package com.example.vrindavan_restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VrindavanRestaurantApplication {

	public static void main(String[] args) {
		SpringApplication.run(VrindavanRestaurantApplication.class, args);
	}

}
