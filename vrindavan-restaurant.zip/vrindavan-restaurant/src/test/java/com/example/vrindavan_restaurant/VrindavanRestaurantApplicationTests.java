package com.example.vrindavan_restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VrindavanRestaurantApplicationTests {

	@Test
	void contextLoads() {
	}

}
